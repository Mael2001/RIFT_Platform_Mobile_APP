
  cordova.define('cordova/plugin_list', function(require, exports, module) {
    module.exports = [
      {
          "id": "cordova-plugin-ftp.ftp",
          "file": "plugins/cordova-plugin-ftp/www/ftp.js",
          "pluginId": "cordova-plugin-ftp",
        "clobbers": [
          "cordova.plugin.ftp"
        ]
        },
      {
          "id": "com.moust.cordova.videoplayer.VideoPlayer",
          "file": "plugins/com.moust.cordova.videoplayer/www/videoplayer.js",
          "pluginId": "com.moust.cordova.videoplayer",
        "clobbers": [
          "VideoPlayer"
        ]
        }
    ];
    module.exports.metadata =
    // TOP OF METADATA
    {
      "cordova-plugin-ftp": "1.2.1",
      "com.moust.cordova.videoplayer": "1.0.1"
    };
    // BOTTOM OF METADATA
    });
    