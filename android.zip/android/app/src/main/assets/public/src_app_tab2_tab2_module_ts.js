"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_tab2_tab2_module_ts"],{

/***/ 8472:
/*!*******************************************!*\
  !*** ./src/app/services/video.service.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VideoService": () => (/* binding */ VideoService)
/* harmony export */ });
/* harmony import */ var _Users_crisdeveloper_Desktop_MARIO_DEV_RIFT_Platform_Mobile_APP_master_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _capacitor_filesystem__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @capacitor/filesystem */ 1662);
/* harmony import */ var _capacitor_storage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @capacitor/storage */ 460);





let VideoService = class VideoService {
  constructor() {
    this.videos = []; // eslint-disable-next-line @typescript-eslint/no-inferrable-types, @typescript-eslint/naming-convention

    this.VIDEOS_KEY = 'videos'; // Helper function

    this.convertBlobToBase64 = blob => new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onerror = reject;

      reader.onload = () => {
        resolve(reader.result);
      };

      reader.readAsDataURL(blob);
    });
  }

  loadVideos() {
    var _this = this;

    return (0,_Users_crisdeveloper_Desktop_MARIO_DEV_RIFT_Platform_Mobile_APP_master_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const videoList = yield _capacitor_storage__WEBPACK_IMPORTED_MODULE_2__.Storage.get({
        key: _this.VIDEOS_KEY
      });
      _this.videos = JSON.parse(videoList.value) || [];
    })();
  }

  storeVideo(blob) {
    var _this2 = this;

    return (0,_Users_crisdeveloper_Desktop_MARIO_DEV_RIFT_Platform_Mobile_APP_master_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const fileName = new Date().getTime() + '.mp4';
      const base64Data = yield _this2.convertBlobToBase64(blob);
      const savedFile = yield _capacitor_filesystem__WEBPACK_IMPORTED_MODULE_1__.Filesystem.writeFile({
        path: fileName,
        data: base64Data,
        directory: _capacitor_filesystem__WEBPACK_IMPORTED_MODULE_1__.Directory.Data
      }); // Add file to local array

      _this2.videos.unshift(savedFile.uri); // Write information to storage


      return _capacitor_storage__WEBPACK_IMPORTED_MODULE_2__.Storage.set({
        key: _this2.VIDEOS_KEY,
        value: JSON.stringify(_this2.videos)
      });
    })();
  } // Load video as base64 from url


  getVideoUrl(fullPath) {
    return (0,_Users_crisdeveloper_Desktop_MARIO_DEV_RIFT_Platform_Mobile_APP_master_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const filePath = fullPath.substr(fullPath.lastIndexOf('/') + 1);
      const file = yield _capacitor_filesystem__WEBPACK_IMPORTED_MODULE_1__.Filesystem.readFile({
        path: filePath,
        directory: _capacitor_filesystem__WEBPACK_IMPORTED_MODULE_1__.Directory.Data
      });
      return `data:video/mp4;base64,${file.data}`;
    })();
  }

};

VideoService.ctorParameters = () => [];

VideoService = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Injectable)({
  providedIn: 'root'
})], VideoService);


/***/ }),

/***/ 3092:
/*!*********************************************!*\
  !*** ./src/app/tab2/tab2-routing.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Tab2PageRoutingModule": () => (/* binding */ Tab2PageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _tab2_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tab2.page */ 442);




const routes = [
    {
        path: '',
        component: _tab2_page__WEBPACK_IMPORTED_MODULE_0__.Tab2Page,
    }
];
let Tab2PageRoutingModule = class Tab2PageRoutingModule {
};
Tab2PageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], Tab2PageRoutingModule);



/***/ }),

/***/ 4608:
/*!*************************************!*\
  !*** ./src/app/tab2/tab2.module.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Tab2PageModule": () => (/* binding */ Tab2PageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _tab2_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tab2.page */ 442);
/* harmony import */ var _explore_container_explore_container_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../explore-container/explore-container.module */ 581);
/* harmony import */ var _tab2_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./tab2-routing.module */ 3092);








let Tab2PageModule = class Tab2PageModule {
};
Tab2PageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonicModule,
            _angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormsModule,
            _explore_container_explore_container_module__WEBPACK_IMPORTED_MODULE_1__.ExploreContainerComponentModule,
            _tab2_routing_module__WEBPACK_IMPORTED_MODULE_2__.Tab2PageRoutingModule
        ],
        declarations: [_tab2_page__WEBPACK_IMPORTED_MODULE_0__.Tab2Page]
    })
], Tab2PageModule);



/***/ }),

/***/ 442:
/*!***********************************!*\
  !*** ./src/app/tab2/tab2.page.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Tab2Page": () => (/* binding */ Tab2Page)
/* harmony export */ });
/* harmony import */ var _Users_crisdeveloper_Desktop_MARIO_DEV_RIFT_Platform_Mobile_APP_master_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _tab2_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tab2.page.html?ngResource */ 1748);
/* harmony import */ var _tab2_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./tab2.page.scss?ngResource */ 1597);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _services_video_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/video.service */ 8472);
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @capacitor/core */ 5099);
/* harmony import */ var _angular_animations__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/animations */ 4851);
/* harmony import */ var _services_upload_service_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../services/upload-service.service */ 4450);
/* harmony import */ var _ionic_native_video_player_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/video-player/ngx */ 3189);






 // eslint-disable-next-line @typescript-eslint/naming-convention

const {
  CapacitorVideoPlayer
} = _capacitor_core__WEBPACK_IMPORTED_MODULE_4__.Plugins;



let Tab2Page = class Tab2Page {
  constructor(videoService, changeDetector, uploadService, videoPlayer) {
    this.videoService = videoService;
    this.changeDetector = changeDetector;
    this.uploadService = uploadService;
    this.videoPlayer = videoPlayer;
    this.isRecording = false;
    this.selectedVideos = [];
    this.videoOptions = {
      //scalingMode: 0,
      volume: 0.7
    };
  }

  getSelected(video) {
    if (this.selectedVideos.indexOf(video) === -1) {
      return false;
    }

    return true;
  }

  selectVideo(video) {
    if (this.selectedVideos.indexOf(video) === -1) {
      this.selectedVideos.push(video);
    } else {
      this.selectedVideos = this.selectedVideos.filter(item => item !== video);
    }

    console.log(video);
  }

  uploadVideos() {
    const imageAmount = this.selectedVideos.length;

    if (imageAmount > 0) {
      alert(`Uploading ${imageAmount} Videos`);
      this.uploadService.uploadVideos(this.selectedVideos);
      this.selectedVideos = [];
    } else {
      alert(`No Videos selected, please select some videos`);
    }
  } // eslint-disable-next-line @angular-eslint/use-lifecycle-interface


  ngAfterViewInit() {
    var _this = this;

    return (0,_Users_crisdeveloper_Desktop_MARIO_DEV_RIFT_Platform_Mobile_APP_master_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this.videoService.loadVideos();
    })();
  }

  recordVideo() {
    var _this2 = this;

    return (0,_Users_crisdeveloper_Desktop_MARIO_DEV_RIFT_Platform_Mobile_APP_master_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      // Create a stream of video capturing
      const stream = yield navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: 'user'
        },
        audio: true
      }); // Show the stream inside our video object

      _this2.captureElement.nativeElement.srcObject = stream;
      const options = {
        mimeType: 'video/webm'
      };
      _this2.mediaRecorder = new MediaRecorder(stream, options);
      const chunks = []; // Store the video on stop

      _this2.mediaRecorder.onstop = /*#__PURE__*/function () {
        var _ref = (0,_Users_crisdeveloper_Desktop_MARIO_DEV_RIFT_Platform_Mobile_APP_master_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (event) {
          const videoBuffer = new Blob(chunks, {
            type: 'video/webm'
          });
          yield _this2.videoService.storeVideo(videoBuffer);

          _this2.changeDetector.detectChanges();
        });

        return function (_x) {
          return _ref.apply(this, arguments);
        };
      }(); // Store chunks of recorded video


      _this2.mediaRecorder.ondataavailable = event => {
        if (event.data && event.data.size > 0) {
          chunks.push(event.data);
        }
      }; // Start recording wth chunks of data


      _this2.mediaRecorder.start(100);

      _this2.isRecording = true;
    })();
  }

  stopRecord() {
    this.mediaRecorder.stop();
    this.mediaRecorder = null;
    this.captureElement.nativeElement.srcObject = null;
    this.isRecording = false;
  }
  /*async play(video) {
    // Get the video as base64 data
    const realUrl = await this.videoService.getVideoUrl(video);
    // Show the player fullscreen
    await this.videoPlayer.initPlayer({
      mode: 'fullscreen',
      url: realUrl,
      playerId: 'fullscreen',
      componentTag: 'app-home'
    });
  }*/


  play(video) {
    console.log(video);
    this.videoPlayer.play(video).then(() => {
      console.log('video finished');
    }).catch(error => {
      console.log(error);
    });
  }

};

Tab2Page.ctorParameters = () => [{
  type: _services_video_service__WEBPACK_IMPORTED_MODULE_3__.VideoService
}, {
  type: _angular_core__WEBPACK_IMPORTED_MODULE_7__.ChangeDetectorRef
}, {
  type: _services_upload_service_service__WEBPACK_IMPORTED_MODULE_5__.UploadService
}, {
  type: _ionic_native_video_player_ngx__WEBPACK_IMPORTED_MODULE_6__.VideoPlayer
}];

Tab2Page.propDecorators = {
  captureElement: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_7__.ViewChild,
    args: ['video']
  }]
};
Tab2Page = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
  selector: 'app-tab2',
  template: _tab2_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  animations: [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.trigger)('selectItem', [// ...
  (0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.state)('notSelected', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.style)({
    height: 'auto',
    opacity: 1,
    backgroundColor: 'transparent'
  })), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.state)('selected', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.style)({
    height: 'auto',
    opacity: 0.4,
    backgroundColor: 'grey'
  })), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.transition)('notSelected => selected', [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.animate)('0.5s')]), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.transition)('selected => notSelected', [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.animate)('0.5s')])])],
  styles: [_tab2_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], Tab2Page);


/***/ }),

/***/ 1597:
/*!************************************************!*\
  !*** ./src/app/tab2/tab2.page.scss?ngResource ***!
  \************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJ0YWIyLnBhZ2Uuc2NzcyJ9 */";

/***/ }),

/***/ 1748:
/*!************************************************!*\
  !*** ./src/app/tab2/tab2.page.html?ngResource ***!
  \************************************************/
/***/ ((module) => {

module.exports = "<ion-header [translucent]=\"true\">\n  <ion-toolbar>\n    <ion-title>\n      Video Handler\n    </ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <!-- Display the video stream while capturing -->\n  <video class=\"video\" vertical=\"center\" horizontal=\"center\" #video autoplay playsinline muted [hidden]=\"!isRecording\"></video>\n\n\n  <ion-content>\n    <ion-grid>\n      <ion-list *ngIf=\"!isRecording\" >\n        <ion-row *ngFor=\"let video of videoService.videos;\" [@selectItem]=\"getSelected(video) ? 'selected' : 'notSelected'\">\n          <ion-col>\n            <ion-item >\n              {{ video }}\n            </ion-item>\n          </ion-col>\n          <ion-col>\n            <ion-button color=\"dark\" horizontal=\"center\" (click)=\"play(video)\">Play Video</ion-button>\n          </ion-col>\n          <ion-col>\n            <ion-checkbox color=\"primary\" [checked]=\"getSelected(video)\"  horizontal=\"center\" (click)=\"selectVideo(video)\"></ion-checkbox>\n          </ion-col>\n        </ion-row>\n      </ion-list>\n    </ion-grid>\n  </ion-content>\n  <ion-fab vertical=\"bottom\" horizontal=\"center\" slot=\"fixed\">\n    <ion-fab-button (click)=\"isRecording ? stopRecord() : recordVideo()\">\n      <ion-icon [name]=\"isRecording ? 'stop' : 'videocam'\"></ion-icon>\n    </ion-fab-button>\n  </ion-fab>\n\n  <ion-fab vertical=\"bottom\" horizontal=\"center\" slot=\"fixed\">\n    <ion-fab-button (click)=\"isRecording ? stopRecord() : recordVideo()\">\n      <ion-icon [name]=\"isRecording ? 'stop' : 'videocam'\"></ion-icon>\n    </ion-fab-button>\n  </ion-fab>\n\n  <ion-fab vertical=\"bottom\" horizontal=\"end\" slot=\"fixed\">\n    <ion-fab-button (click)=\"uploadVideos()\">\n      <ion-icon name=\"cloud-upload\"></ion-icon>\n    </ion-fab-button>\n  </ion-fab>";

/***/ })

}]);
//# sourceMappingURL=src_app_tab2_tab2_module_ts.js.map